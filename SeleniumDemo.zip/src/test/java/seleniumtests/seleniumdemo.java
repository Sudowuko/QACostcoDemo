package seleniumtests;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.Keys;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class seleniumdemo {
    public static void main(String[] args) {
        // Starting web application for Costco
        System.setProperty("webdriver.chrome.driver", "C:\\Users\\jnicolas\\Downloads\\chromedriver.exe");
        WebDriver driver = new ChromeDriver();
        driver.manage().window().maximize();
        driver.get("https://www.costco.ca/");

        //Obtaining title
        System.out.println(driver.getTitle());

        //Inserting test value in to the search box
        var searchPath = "//*[@id=\"search-field\"]";
        var test = "toilet paper";
        WebElement m = driver.findElement(By.xpath(searchPath));
        m.sendKeys(test);
        m.sendKeys(Keys.ENTER);

        //Scrolling up and down
        JavascriptExecutor js = (JavascriptExecutor) driver;
        for (int i = 0; i < 2000; i++) {
            js.executeScript("window.scrollBy(0,2)", "");
        }

        for (int i = 0; i < 2000; i++) {
            js.executeScript("window.scrollBy(0,-2)", "");
        }

        //Selecting and using dropdown
        var dropDownPath = "//*[@id=\"sort_by\"]";
        m = driver.findElement(By.xpath(dropDownPath));
        m.click();
        try {
            Thread.sleep(1000);
        } catch  (InterruptedException e) {
            e.printStackTrace();
        }
        Select dropdown = new Select(driver.findElement(By.xpath(dropDownPath)));
        dropdown.selectByVisibleText("Most Viewed");

        //Selecting first item
        var firstItemPath = "//*[@id=\"price-585578\"]";
        m = driver.findElement(By.xpath(firstItemPath));
        m.click();


        //Adding to cart
        var addCartPath = "//*[@id=\"add-to-cart-btn\"]";
        m = driver.findElement(By.xpath(addCartPath));
        m.click();

        //Waiting for the add to cart button to appear
        try {
            Thread.sleep(12000);
        } catch  (InterruptedException e) {
            e.printStackTrace();
        }

        //Going to cart to see checkout
        var checkoutPath = "//*[@id=\"costcoModalText\"]/div[2]/div[2]/a/button";
        m = driver.findElement(By.xpath(checkoutPath));
        m.click();


















    }

}
